import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-insulina-emergencial',
  templateUrl: 'insulina-emergencial.html'
})
export class InsulinaEmergencialPage {

  constructor(public navCtrl: NavController) {
  }
  
}
