import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-calcular-dose',
  templateUrl: 'calcular-dose.html'
})
export class CalcularDosePage {

  constructor(public navCtrl: NavController) {
  }
  
}
