import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-configura-es-do-aplicativo',
  templateUrl: 'configura-es-do-aplicativo.html'
})
export class ConfiguraEsDoAplicativoPage {

  constructor(public navCtrl: NavController) {
  }
  
}
