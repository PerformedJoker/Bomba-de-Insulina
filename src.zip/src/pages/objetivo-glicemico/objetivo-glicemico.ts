import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-objetivo-glicemico',
  templateUrl: 'objetivo-glicemico.html'
})
export class ObjetivoGlicemicoPage {

  constructor(public navCtrl: NavController) {
  }
  
}
