import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-visualizar-tabela-resumo',
  templateUrl: 'visualizar-tabela-resumo.html'
})
export class VisualizarTabelaResumoPage {

  constructor(public navCtrl: NavController) {
  }
  
}
